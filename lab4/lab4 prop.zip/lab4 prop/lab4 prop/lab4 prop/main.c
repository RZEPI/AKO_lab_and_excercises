#include <stdio.h>

unsigned int* tablica_parzystych(unsigned int tablica[], unsigned int* n);

int main()
{
	unsigned int tablica[] = { 1, 2, 2, 3, 6, 8, 0, 3 };
	unsigned int n = 8;
	unsigned int* tablicaParz = tablica_parzystych(tablica, &n);
	if (tablicaParz == 0)
		return 0;
	for (int i = 0; i < n; i++)
		printf("%d, ", tablicaParz[i]);
	return 0;
}